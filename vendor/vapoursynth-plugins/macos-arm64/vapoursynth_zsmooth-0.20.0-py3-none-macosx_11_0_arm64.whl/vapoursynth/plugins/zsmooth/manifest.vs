[VapourSynth Manifest V1]
libzsmooth
