[VapourSynth Manifest V1]
libvszip
